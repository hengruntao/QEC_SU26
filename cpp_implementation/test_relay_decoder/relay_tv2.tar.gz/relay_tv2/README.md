# relay_tv2 — Relay-BP functional test vectors

562 cases × 4 parameter sets = **2248 vectors** for the `[[144,12,12]]` gross code,
generated from the authors' own reference implementation
(`trmue/relay`, arXiv:2506.01779) used as a blind oracle.

Read `SPEC2.md` before trusting any number out of this package — it is the
contract, and §6 says explicitly what is and is not checked.

## Layout

```
include/relay_tv2.h          types, dimensions, extern declarations
src/relay_tv2_data.c         H_X, 562 cases, 4 × 562 expected outputs
test/run_vectors2.cpp        harness + the adapter for decode_relay()
json/vectors2.json           the same data as JSON
tools/gen_cases2.py          designs the case suite (INPUTS only)
tools/vecgen2.rs             drives the reference decoder, emits expected outputs
tools/emit_c2.py             builds this package
tools/oracle_in.txt          the exact problem file handed to the oracle
tools/oracle_out.txt         the exact raw oracle output
tools/reference_build_only.patch   the build-only diff applied to the reference
SPEC2.md                     the contract
```

## Build and run

From `cpp_implementation/`, with this directory placed inside it:

```sh
clang++ -O2 -I. -Irelay_tv2/include \
    relay_tv2/test/run_vectors2.cpp relay_tv2/src/relay_tv2_data.c \
    Relay_BP/relay_decoder.cpp DMem_BP/dmem_bp.cpp \
    vnu/vnu_int4.cpp vnu/RNG.cpp cnu/cnu_int4.cpp -o run_vectors2
```

```sh
./run_vectors2                       # auto-picks the set matching your #defines
./run_vectors2 --list                # show the four parameter sets
./run_vectors2 hw_R8_S5 --csv out.csv   # force a set, dump per-case results
```

The harness reads `RELAY_T0 / RELAY_TR / RELAY_R / RELAY_S` out of your
`Relay_BP/relay_decoder.h` and selects the matching vector set on its own. If
none matches it refuses to run rather than silently comparing against a
different budget. To run the paper's setting, edit that header to
`RELAY_R 600`, `RELAY_S 5` and rebuild.

The first thing it prints is an `H_X` consistency check against your
`generated/code_matrices.h`. If that ever fails, stop — every downstream number
would be meaningless.

Exit code is non-zero only on a false positive (decoder claims success but
`H·ê ≠ s`).

## Baseline: what this repo's committed decoder scores

Measured in a container on `hengruntao/QEC_SU26` @ `5e2bf1e`, recompiling only
`RELAY_R` / `RELAY_S` per row. Reproduce these before reading anything into a
change you make.

| config | false positives | converged agrees | weight better / equal / worse | bit-identical ê |
|---|---|---|---|---|
| `paper_R600_S1` | 0 | 562 / 562 | 41 / 402 / 119 | 278 |
| `paper_R600_S5` | 0 | 562 / 562 | 9 / 464 / 89 | 306 |
| `hw_R8_S1` | 0 | 549 / 562 | 39 / 393 / 117 | 277 |
| `hw_R8_S5` | 0 | 549 / 562 | 19 / 441 / 89 | 295 |

All 13 convergence disagreements are the same direction: the DUT converged
where the reference did not. There is no case in any configuration where the
reference converged and the DUT did not.

`paper_R600_S5`, broken down by group:

| group | n | better | equal | worse | bit-identical |
|---|---|---|---|---|---|
| `A` + `B` (smoke) | 17 | 0 | 17 | 0 | 17 |
| `P01`–`P08` | 185 | 0 | 181 | 4 | 168 |
| `P09`–`P14` | 280 | 8 | 241 | 31 | 115 |
| `P15` | 35 | 0 | 8 | 27 | 1 |
| `C20`/`C25`/`C30` | 45 | 1 | 17 | 27 | 5 |

Where the DUT is heavier it is heavier by 2.36 columns on average, 6 at worst.
DUT iteration counts run below the reference's (mean 217 vs 304, max 1384 vs 1980).
