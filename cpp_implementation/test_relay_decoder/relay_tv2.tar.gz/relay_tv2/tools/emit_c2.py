#!/usr/bin/env python3
"""Build the relay_tv2 C package from the oracle problem + result files.

Inputs   : tv/oracle_in.txt, tv/oracle_out.txt, tv/H_X.npy
Outputs  : relay_tv2/include/relay_tv2.h
           relay_tv2/src/relay_tv2_data.c
           relay_tv2/json/vectors2.json
This script contains no decoder logic: it only reformats oracle output.
"""
import json
import math
import os
import numpy as np

TV = '/home/claude/tv'
OUT = '/home/claude/relay_tv2'

DATA_SCALE = 2      # S in intN.S.M  (int4.2.8)
MAX_VAL = 15        # 2^N - 1, N = 4 magnitude bits


def lambda0_int(p):
    """Paper arXiv:2510.21600 sec. 4.2:  Lambda_j(0) = log((1-p_j)/p_j), scaled by S,
    standard rounding to integer; priors are unsigned, magnitude clamped to 2^N-1."""
    lam = DATA_SCALE * math.log((1.0 - p) / p)
    v = int(math.floor(lam + 0.5))          # round-half-up, i.e. the paper's floor(.)ceil
    return max(0, min(MAX_VAL, v))


def main():
    H = np.load(f'{TV}/H_X.npy')
    ROWS, COLS = H.shape

    configs, cases, order = [], {}, []
    for line in open(f'{TV}/oracle_in.txt'):
        f = line.split()
        if not f:
            continue
        if f[0] == 'CONFIG':
            configs.append(dict(name=f[1], t0=int(f[2]), tr=int(f[3]),
                                r=int(f[4]), s=int(f[5]), seed=int(f[6])))
        elif f[0] == 'CASE':
            cid, p, w = f[1], float(f[2]), int(f[3])
            cases[cid] = dict(id=cid, p=p, err=[int(v) for v in f[4:]])
            assert len(cases[cid]['err']) == w
            order.append(cid)

    expect = {c['name']: {} for c in configs}
    for line in open(f'{TV}/oracle_out.txt'):
        f = line.split()
        if f[0] == 'SYND':
            cases[f[1]]['synd'] = [int(v) for v in f[3:]]
            assert len(cases[f[1]]['synd']) == int(f[2])
        elif f[0] == 'RES':
            cid, cfg = f[1], f[2]
            expect[cfg][cid] = dict(converged=int(f[3]), iterations=int(f[4]),
                                    quality=float(f[5]),
                                    ehat=[int(v) for v in f[7:]])
            assert len(expect[cfg][cid]['ehat']) == int(f[6])

    # ---- independent re-derivation: every "converged" e_hat must satisfy H.e = s
    bad = 0
    for cfg in expect:
        for cid, e in expect[cfg].items():
            if not e['converged']:
                continue
            v = np.zeros(COLS, np.uint8)
            v[e['ehat']] = 1
            s = (H @ v) % 2
            ref = np.zeros(ROWS, np.uint8)
            ref[cases[cid]['synd']] = 1
            if not (s == ref).all():
                bad += 1
    print(f'oracle self-check: converged solutions violating H.e_hat = s : {bad}')
    assert bad == 0

    os.makedirs(f'{OUT}/include', exist_ok=True)
    os.makedirs(f'{OUT}/src', exist_ok=True)
    os.makedirs(f'{OUT}/json', exist_ok=True)
    os.makedirs(f'{OUT}/tools', exist_ok=True)
    os.makedirs(f'{OUT}/test', exist_ok=True)

    NC, NG = len(order), len(configs)

    # ------------------------------------------------------------- header ---
    hdr = f'''/* relay_tv2.h -- Relay-BP functional test vectors, generated package.
 *
 * Oracle : trmue/relay (arXiv:2506.01779), the reference implementation
 *          published with the Relay-BP paper, built and run unmodified
 *          except for the build-only changes listed in SPEC2.md sec. 1.
 * Code   : [[144,12,12]] bivariate bicycle "gross" code, code-level H_X,
 *          A = x^3+y+y^2, B = y^3+x+x^2, l=12, m=6.
 * Noise  : i.i.d. code-capacity Bernoulli(p) on the 144 columns.
 *
 * DO NOT EDIT -- produced by tools/emit_c2.py.
 */
#ifndef RELAY_TV2_H
#define RELAY_TV2_H

#ifdef __cplusplus
extern "C" {{
#endif

#define TV2_M            {ROWS}   /* checks    (rows of H_X)    */
#define TV2_N            {COLS}  /* variables (cols of H_X)    */
#define TV2_NUM_CASES    {NC}
#define TV2_NUM_CONFIGS  {NG}

/* intN.S.M parameters used to derive lambda0_int (paper sec. 4.2 / 4.2.1) */
#define TV2_DATA_SCALE   {DATA_SCALE}    /* S */
#define TV2_MAX_VAL      {MAX_VAL}   /* 2^N - 1, N = 4 magnitude bits */
#define TV2_MEM_SCALE    8    /* M */

typedef struct {{
    const char  *name;
    int          t0;      /* T0  : max iterations, leg 0                   */
    int          tr;      /* Tr  : max iterations, each relay leg          */
    int          r;       /* R   : number of relay legs AFTER leg 0        */
    int          s;       /* S   : number of solutions sought (0 = all)    */
    unsigned int seed;    /* reference gamma-RNG seed                      */
}} tv2_config_type;

typedef struct {{
    const char  *id;
    double       p;            /* physical error rate of the prior         */
    int          lambda0_int;  /* round(S * log((1-p)/p)), clamped to 2^N-1 */
    int          err_w;
    const short *err;          /* injected error support, length err_w     */
    int          synd_w;
    const short *synd;         /* syndrome support, length synd_w          */
}} tv2_case_type;

typedef struct {{
    int          converged;    /* reference convergence flag               */
    int          iterations;   /* reference total iteration count          */
    double       quality;      /* sum of log((1-p)/p) over e_hat support   */
    int          ehat_w;       /* reference solution weight                */
    const short *ehat;         /* reference e_hat support, length ehat_w   */
}} tv2_expect_type;

extern const unsigned char   tv2_H_X[TV2_M * TV2_N];
extern const tv2_config_type tv2_configs[TV2_NUM_CONFIGS];
extern const tv2_case_type   tv2_cases[TV2_NUM_CASES];
/* tv2_expect[config][case] */
extern const tv2_expect_type tv2_expect[TV2_NUM_CONFIGS][TV2_NUM_CASES];

#ifdef __cplusplus
}}
#endif
#endif /* RELAY_TV2_H */
'''
    open(f'{OUT}/include/relay_tv2.h', 'w').write(hdr)

    # --------------------------------------------------------------- data ---
    w = []
    w.append('/* relay_tv2_data.c -- DO NOT EDIT, produced by tools/emit_c2.py */\n')
    w.append('#include "relay_tv2.h"\n\n')

    w.append(f'const unsigned char tv2_H_X[TV2_M * TV2_N] = {{\n')
    for r in range(ROWS):
        w.append('  ' + ','.join(str(int(v)) for v in H[r]) + (',\n' if r < ROWS - 1 else '\n'))
    w.append('};\n\n')

    w.append('const tv2_config_type tv2_configs[TV2_NUM_CONFIGS] = {\n')
    for c in configs:
        w.append(f'  {{ "{c["name"]}", {c["t0"]}, {c["tr"]}, {c["r"]}, {c["s"]}, {c["seed"]}u }},\n')
    w.append('};\n\n')

    def arr(name, vals):
        if not vals:
            return f'static const short {name}[1] = {{0}};\n'
        return f'static const short {name}[{len(vals)}] = {{' + ','.join(map(str, vals)) + '};\n'

    for i, cid in enumerate(order):
        c = cases[cid]
        w.append(arr(f'e_{i}', c['err']))
        w.append(arr(f's_{i}', c['synd']))
    w.append('\nconst tv2_case_type tv2_cases[TV2_NUM_CASES] = {\n')
    for i, cid in enumerate(order):
        c = cases[cid]
        w.append(f'  {{ "{cid}", {c["p"]!r}, {lambda0_int(c["p"])}, '
                 f'{len(c["err"])}, e_{i}, {len(c["synd"])}, s_{i} }},\n')
    w.append('};\n\n')

    for g, cfg in enumerate(configs):
        for i, cid in enumerate(order):
            w.append(arr(f'h_{g}_{i}', expect[cfg['name']][cid]['ehat']))
    w.append('\nconst tv2_expect_type tv2_expect[TV2_NUM_CONFIGS][TV2_NUM_CASES] = {\n')
    for g, cfg in enumerate(configs):
        w.append(f'  {{ /* {cfg["name"]} */\n')
        for i, cid in enumerate(order):
            e = expect[cfg['name']][cid]
            w.append(f'    {{ {e["converged"]}, {e["iterations"]}, {e["quality"]!r}, '
                     f'{len(e["ehat"])}, h_{g}_{i} }},\n')
        w.append('  },\n')
    w.append('};\n')
    open(f'{OUT}/src/relay_tv2_data.c', 'w').write(''.join(w))

    # --------------------------------------------------------------- json ---
    js = dict(
        oracle='trmue/relay (arXiv:2506.01779), unmodified semantics',
        code='[[144,12,12]] bivariate bicycle gross code, code-level H_X (72x144)',
        intN_S_M=dict(N=4, S=DATA_SCALE, M=8),
        configs=configs,
        cases=[dict(id=cid, p=cases[cid]['p'], lambda0_int=lambda0_int(cases[cid]['p']),
                    error=cases[cid]['err'], syndrome=cases[cid]['synd'],
                    expected={c['name']: expect[c['name']][cid] for c in configs})
               for cid in order],
    )
    json.dump(js, open(f'{OUT}/json/vectors2.json', 'w'), indent=1)

    sz = os.path.getsize(f'{OUT}/src/relay_tv2_data.c')
    print(f'cases {NC}  configs {NG}  data.c {sz/1024:.0f} KiB  '
          f'json {os.path.getsize(f"{OUT}/json/vectors2.json")/1024:.0f} KiB')
    print('lambda0_int by p:',
          {p: lambda0_int(p) for p in sorted({c["p"] for c in cases.values()})})


if __name__ == '__main__':
    main()
