#!/usr/bin/env python3
"""Design the Relay-BP test-vector suite (INPUTS ONLY) and emit the oracle problem file.

Nothing in this file encodes decoder behaviour.  Every expected output comes
from the unmodified trmue/relay reference decoder driven by examples/vecgen2.rs.
"""
import sys
import numpy as np

H = np.load('/home/claude/tv/H_X.npy')          # (72, 144), qldpc BBCode gross code
ROWS, COLS = H.shape

# ---------------------------------------------------------------- configs ---
# Paper (Maurer et al., arXiv:2510.21600, Fig. 7 caption):
#   gamma0 = 0.125, gamma in [-0.24, 0.66], beta_int in [3,10], T0 = 80, Tr = 60, R = 600
# S (number of solutions sought) is not fixed by the Fig. 7 caption; the authors'
# production notebook uses relay_stop_nconv = 5, the unit tests use 1.
#   name             T0   Tr    R   S   seed
CONFIGS = [
    ("paper_R600_S1", 80, 60, 600, 1, 0),
    ("paper_R600_S5", 80, 60, 600, 5, 0),
    ("hw_R8_S1",      80, 60,   8, 1, 0),
    ("hw_R8_S5",      80, 60,   8, 5, 0),
]

# ------------------------------------------------------------------ cases ---
# Group 0: deterministic weight anchors (regression / smoke).
# Group 1: i.i.d. Bernoulli(p) code-capacity noise, p swept to span
#          "converges inside leg 0" .. "does not converge at all".
P_LEVELS = [0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.07,
            0.08, 0.09, 0.10, 0.11, 0.12, 0.13, 0.14, 0.15]
COUNTS   = [  10,   10,   15,   20,   25,   30,   35,
               40,   45,   50,   50,   50,   45,   40,   35]

RNG_SEED = 20260918


def lambda0_int(p, data_scale=2, max_val=15):
    """int4.2.8 quantisation of lambda = log((1-p)/p): round(S*lambda), clamped."""
    lam = np.log((1.0 - p) / p)
    v = int(np.rint(data_scale * lam))
    return max(-max_val, min(max_val, v))


def main():
    rng = np.random.default_rng(RNG_SEED)
    cases = []          # (id, p, support)

    # --- group A: fixed weights, p pinned at 0.05 so the prior is well defined
    for w in [0, 1, 2, 3, 4, 5, 6, 8, 10, 12]:
        sup = sorted(rng.choice(COLS, size=w, replace=False).tolist()) if w else []
        cases.append((f"A_w{w:02d}", 0.05, sup))

    # --- group B: every single-column error (catches column-indexing bugs)
    for j in [0, 1, 71, 72, 73, 142, 143]:
        cases.append((f"B_col{j:03d}", 0.05, [j]))

    # --- group C: over-noise, to exercise the total-non-convergence path
    for p in [0.20, 0.25, 0.30]:
        for k in range(15):
            e = rng.random(COLS) < p
            cases.append((f"C{int(p*100):02d}_{k:03d}", float(p), np.flatnonzero(e).tolist()))

    # --- group P: random Bernoulli(p)
    for p, n in zip(P_LEVELS, COUNTS):
        for k in range(n):
            e = rng.random(COLS) < p
            sup = np.flatnonzero(e).tolist()
            cases.append((f"P{int(p*100):02d}_{k:03d}", float(p), sup))

    out = []
    out.append(f"H {ROWS} {COLS}")
    for r in range(ROWS):
        sup = np.flatnonzero(H[r]).tolist()
        out.append("HROW " + str(r) + " " + " ".join(map(str, sup)))
    for (name, t0, tr, R, S, seed) in CONFIGS:
        out.append(f"CONFIG {name} {t0} {tr} {R} {S} {seed}")
    for (cid, p, sup) in cases:
        out.append(f"CASE {cid} {p!r} {len(sup)} " + " ".join(map(str, sup)))

    path = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/tv/oracle_in.txt'
    open(path, 'w').write("\n".join(out) + "\n")

    # side file: per-case metadata the harness needs but the oracle does not
    meta = ["case_id,p,lambda0_int,weight"]
    for (cid, p, sup) in cases:
        meta.append(f"{cid},{p},{lambda0_int(p)},{len(sup)}")
    open('/home/claude/tv/cases_meta.csv', 'w').write("\n".join(meta) + "\n")

    print(f"cases: {len(cases)}  configs: {len(CONFIGS)}  -> {path}")
    ws = [len(s) for (_, _, s) in cases]
    print(f"error weight: min {min(ws)} max {max(ws)} mean {np.mean(ws):.2f}")


if __name__ == '__main__':
    main()
