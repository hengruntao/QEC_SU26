// Test-vector generator #2.
//
// Drives the UNMODIFIED trmue/relay reference decoder (arXiv:2506.01779) as an
// oracle.  Reads a plain-text problem file, writes a plain-text result file.
// Contains no knowledge of, and no dependency on, any user implementation.
//
// The only change made to the reference crate is build-only:
//   * crates/relay_bp/src/bp/mod.rs -- `min_sum_fixed` module commented out
//     (it pulls in the `fixed` crate, MSRV 1.83; unused for f64/isize decoders)
//   * criterion dev-dependency + [[bench]] sections removed
//   * Cargo.lock format marker 4 -> 3
// `cargo test --release` still reports 11/11 pass after these changes.

use ndarray::{Array1, Array2};
use relay_bp::bipartite_graph::{BipartiteGraph, SparseBipartiteGraph};
use relay_bp::bp::min_sum::MinSumDecoderConfig;
use relay_bp::bp::relay::{RelayDecoderConfig, RelayDecoder, StoppingCriterion};
use relay_bp::decoder::{Bit, Decoder};
use std::env;
use std::fs;
use std::io::Write;
use std::sync::Arc;

struct Cfg {
    name: String,
    pre_iter: usize,
    set_max_iter: usize,
    num_sets: usize,
    stop_nconv: usize, // 0 => StoppingCriterion::All
    seed: u64,
}

struct Case {
    id: String,
    p: f64,
    err: Vec<usize>, // support of the injected error
}

fn main() {
    let args: Vec<String> = env::args().collect();
    let in_path = &args[1];
    let out_path = &args[2];

    let text = fs::read_to_string(in_path).expect("read input");
    let mut rows = 0usize;
    let mut cols = 0usize;
    let mut h_rows: Vec<Vec<usize>> = Vec::new();
    let mut cfgs: Vec<Cfg> = Vec::new();
    let mut cases: Vec<Case> = Vec::new();

    for line in text.lines() {
        let f: Vec<&str> = line.split_whitespace().collect();
        if f.is_empty() {
            continue;
        }
        match f[0] {
            "H" => {
                rows = f[1].parse().unwrap();
                cols = f[2].parse().unwrap();
            }
            "HROW" => {
                h_rows.push(f[2..].iter().map(|v| v.parse().unwrap()).collect());
            }
            "CONFIG" => cfgs.push(Cfg {
                name: f[1].to_string(),
                pre_iter: f[2].parse().unwrap(),
                set_max_iter: f[3].parse().unwrap(),
                num_sets: f[4].parse().unwrap(),
                stop_nconv: f[5].parse().unwrap(),
                seed: f[6].parse().unwrap(),
            }),
            "CASE" => cases.push(Case {
                id: f[1].to_string(),
                p: f[2].parse().unwrap(),
                err: f[4..].iter().map(|v| v.parse().unwrap()).collect(),
            }),
            _ => {}
        }
    }
    assert_eq!(h_rows.len(), rows);

    // dense H -> SparseBitMatrix
    let mut dense = Array2::<u8>::zeros((rows, cols));
    for (r, sup) in h_rows.iter().enumerate() {
        for &c in sup {
            dense[[r, c]] = 1;
        }
    }
    let graph: SparseBipartiteGraph<u8> = SparseBipartiteGraph::from_dense(dense.clone());
    let graph = Arc::new(graph);

    let mut out = std::io::BufWriter::new(fs::File::create(out_path).expect("create out"));

    for case in &cases {
        // syndrome = H . e  (mod 2)
        let mut syn: Array1<Bit> = Array1::zeros(rows);
        for (r, sup) in h_rows.iter().enumerate() {
            let mut acc = 0u8;
            for &c in sup {
                if case.err.contains(&c) {
                    acc ^= 1;
                }
            }
            syn[r] = acc;
        }
        writeln!(
            out,
            "SYND {} {} {}",
            case.id,
            syn.iter().filter(|&&b| b == 1).count(),
            syn.iter()
                .enumerate()
                .filter(|(_, &b)| b == 1)
                .map(|(i, _)| i.to_string())
                .collect::<Vec<_>>()
                .join(" ")
        )
        .unwrap();

        for cfg in &cfgs {
            // Paper Fig. 7 arithmetic: alpha = 1 - 2^-t  (reference sentinel: Some(0.)),
            // gamma0 = 0.125, gamma ~ U[-0.24, 0.66].
            let bp = MinSumDecoderConfig {
                error_priors: Array1::from_elem(cols, case.p),
                max_iter: cfg.pre_iter,
                alpha: Some(0.0),
                alpha_iteration_scaling_factor: 1.0,
                gamma0: Some(0.125),
                ..Default::default()
            };
            let rc = RelayDecoderConfig {
                pre_iter: cfg.pre_iter,
                num_sets: cfg.num_sets,
                set_max_iter: cfg.set_max_iter,
                gamma_dist_interval: (-0.24, 0.66),
                explicit_gammas: None,
                stopping_criterion: if cfg.stop_nconv == 0 {
                    StoppingCriterion::All
                } else {
                    StoppingCriterion::NConv {
                        stop_after: cfg.stop_nconv,
                    }
                },
                logging: false,
                seed: cfg.seed,
            };
            // Fresh decoder per (case, config): the gamma RNG state lives in the
            // decoder and would otherwise carry over between cases.
            let mut dec: RelayDecoder<f64> =
                RelayDecoder::new(graph.clone(), Arc::new(bp), Arc::new(rc));
            let r = dec.decode_detailed(syn.view());
            let sup: Vec<String> = r
                .decoding
                .iter()
                .enumerate()
                .filter(|(_, &b)| b == 1)
                .map(|(i, _)| i.to_string())
                .collect();
            writeln!(
                out,
                "RES {} {} {} {} {} {} {}",
                case.id,
                cfg.name,
                r.success as u8,
                r.iterations,
                if r.decoding_quality == f64::MAX {
                    -1.0
                } else {
                    r.decoding_quality
                },
                sup.len(),
                sup.join(" ")
            )
            .unwrap();
        }
    }
    eprintln!("done: {} cases x {} configs", cases.len(), cfgs.len());
}
