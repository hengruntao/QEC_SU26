/* relay_tv2.h -- Relay-BP functional test vectors, generated package.
 *
 * Oracle : trmue/relay (arXiv:2506.01779), the reference implementation
 *          published with the Relay-BP paper, built and run unmodified
 *          except for the build-only changes listed in SPEC2.md sec. 1.
 * Code   : [[144,12,12]] bivariate bicycle "gross" code, code-level H_X,
 *          A = x^3+y+y^2, B = y^3+x+x^2, l=12, m=6.
 * Noise  : i.i.d. code-capacity Bernoulli(p) on the 144 columns.
 *
 * DO NOT EDIT -- produced by tools/emit_c2.py.
 */
#ifndef RELAY_TV2_H
#define RELAY_TV2_H

#ifdef __cplusplus
extern "C" {
#endif

#define TV2_M            72   /* checks    (rows of H_X)    */
#define TV2_N            144  /* variables (cols of H_X)    */
#define TV2_NUM_CASES    562
#define TV2_NUM_CONFIGS  4

/* intN.S.M parameters used to derive lambda0_int (paper sec. 4.2 / 4.2.1) */
#define TV2_DATA_SCALE   2    /* S */
#define TV2_MAX_VAL      15   /* 2^N - 1, N = 4 magnitude bits */
#define TV2_MEM_SCALE    8    /* M */

typedef struct {
    const char  *name;
    int          t0;      /* T0  : max iterations, leg 0                   */
    int          tr;      /* Tr  : max iterations, each relay leg          */
    int          r;       /* R   : number of relay legs AFTER leg 0        */
    int          s;       /* S   : number of solutions sought (0 = all)    */
    unsigned int seed;    /* reference gamma-RNG seed                      */
} tv2_config_type;

typedef struct {
    const char  *id;
    double       p;            /* physical error rate of the prior         */
    int          lambda0_int;  /* round(S * log((1-p)/p)), clamped to 2^N-1 */
    int          err_w;
    const short *err;          /* injected error support, length err_w     */
    int          synd_w;
    const short *synd;         /* syndrome support, length synd_w          */
} tv2_case_type;

typedef struct {
    int          converged;    /* reference convergence flag               */
    int          iterations;   /* reference total iteration count          */
    double       quality;      /* sum of log((1-p)/p) over e_hat support   */
    int          ehat_w;       /* reference solution weight                */
    const short *ehat;         /* reference e_hat support, length ehat_w   */
} tv2_expect_type;

extern const unsigned char   tv2_H_X[TV2_M * TV2_N];
extern const tv2_config_type tv2_configs[TV2_NUM_CONFIGS];
extern const tv2_case_type   tv2_cases[TV2_NUM_CASES];
/* tv2_expect[config][case] */
extern const tv2_expect_type tv2_expect[TV2_NUM_CONFIGS][TV2_NUM_CASES];

#ifdef __cplusplus
}
#endif
#endif /* RELAY_TV2_H */
