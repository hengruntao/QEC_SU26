# SPEC2 — contract for the `relay_tv2` Relay-BP test vectors

562 cases × 4 parameter sets = 2248 vectors.
Expected outputs come from the reference implementation published with
arXiv:2506.01779 (`github.com/trmue/relay`), built and driven as an oracle.
No decoder under test was read while designing the cases or deriving the
expectations.

---

## 1. Oracle provenance

The reference crate was built at commit `HEAD` of `trmue/relay` with rustc 1.75.
Three changes were needed to build it, **all build-only**:

| change | reason |
|---|---|
| `crates/relay_bp/src/bp/mod.rs`: `pub mod min_sum_fixed;` commented out | pulls in the `fixed` crate (MSRV 1.83); only used for `FixedI64` decoders, which this package does not exercise |
| `criterion` dev-dependency and both `[[bench]]` sections removed | `criterion` fails to resolve under rustc 1.75 |
| `Cargo.lock` format marker `version = 4` → `3` | cargo 1.75 cannot parse lockfile v4; the pinned dependency versions are untouched |

Nothing in `relay.rs`, `min_sum.rs` or `decoder.rs` was modified.
`cargo test --release` reports **11 / 11 pass** after the changes, including
`bp::relay::tests::decode_144_12_12` and `..._int`.

The oracle driver is `tools/vecgen2.rs`. It constructs a fresh
`RelayDecoder<f64>` per (case, config) — the γ RNG state lives inside the
decoder, so reusing one instance would make case *n* depend on case *n−1*.

---

## 2. Code and noise model

* `H_X` is the code-level X-check matrix of the `[[144,12,12]]` bivariate
  bicycle *gross code*, `BBCode({x:12, y:6}, x^3+y+y^2, y^3+x+x^2)` from `qldpc`.
  72 × 144, CN degree 6, VN degree 3, rank 66 (6 redundant rows).
* It was verified **byte-identical** to `cpp_implementation/generated/code_matrices.h`
  (`h_x[10368]`, sha256 `195d5586a406f019…`). `run_vectors2.cpp` re-checks this
  at startup and aborts if it ever stops holding.
* Noise is i.i.d. code-capacity Bernoulli(p) over the 144 columns.
  **This is not the paper's noise model** — see §7.

---

## 3. Parameters

From the paper, Fig. 7 caption (arXiv:2510.21600, pp. 11 and 15):

> Relay-S γ₀ = 0.125, γ ∈ [−0.24, 0.66], β_int ∈ [3, 10], T₀ = 80, T_r = 60, R = 600.

`S` (number of solutions sought) is not fixed by that caption. The reference's
unit tests use `stop_after = 1`; the authors' production notebook uses 5. Both
are provided.

| config | T₀ | T_r | R | S |
|---|---|---|---|---|
| `paper_R600_S1` | 80 | 60 | 600 | 1 |
| `paper_R600_S5` | 80 | 60 | 600 | 5 |
| `hw_R8_S1` | 80 | 60 | 8 | 1 |
| `hw_R8_S5` | 80 | 60 | 8 | 5 |

`R` counts relay legs **after** leg 0; the reference loops `for set in 1..=num_sets`,
so total legs = R + 1.

α is the scheduled min-sum factor **α = 1 − 2^(−t)**. In the reference this is
selected by the sentinel `alpha: Some(0.0)` together with
`alpha_iteration_scaling_factor = 1.0` — **not** by `alpha: None`, which is the
constant 1.0 (`min_sum.rs:308–316`). Getting this backwards silently changes
every message magnitude.

---

## 4. λ₀ — derived by the paper's stated rule, no tuning

Paper §4 and §4.2:

* Λ_j(0) = ν_{j→i}(0) = log((1 − p_j)/p_j)
* `intN.S.M`: N magnitude bits, S the log-probability→integer scale, M the
  memory-strength scale; *"standard rounding of fractional values to integers"*
* §4.2.1: priors Λ_j(0) are **unsigned**; N = 4 ⇒ magnitude ≤ 15

So `lambda0_int = clamp(round(S · ln((1−p)/p)), 0, 2^N − 1)` with S = 2, N = 4:

| p | 0.01 | 0.03 | 0.05 | 0.08 | 0.10 | 0.12 | 0.15 | 0.25 |
|---|---|---|---|---|---|---|---|---|
| λ₀ | 9 | 7 | 6 | 5 | 4 | 4 | 3 | 2 |

Each case carries its own matched λ₀. There is no global override: a swept λ₀
would no longer be the prior the oracle used, and the weight comparison would
stop meaning anything.

---

## 5. Reference semantics that are easy to get wrong

Read from `relay.rs` / `min_sum.rs`; each is exercised by the suite.

1. **Iteration accounting.** If leg 0 converges and the stopping criterion is
   met, `iterations` is leg 0's own count. Otherwise `iterations` is the
   running total across every executed leg (`relay.rs:329` vs `:372`).
2. **What a new leg resets.** C2V messages are cleared and V2C is reset to the
   prior; the iteration counter is cleared; the posterior Λ is **not** reset.
   That is the relay.
3. **Total non-convergence.** `result` is initialised to leg 0 and only
   replaced inside `if temp_result.success`, so a decode that never converges
   returns **leg 0's ê** — neither the last leg's nor a best-so-far.
4. **Best-solution selection.** Replacement uses strict `pm < min_pm`, so a tie
   keeps the *earlier* leg.
5. **Decoding quality.** `Σ_{j: ê_j = 1} log((1−p_j)/p_j)`. With a uniform prior
   this is Hamming weight times a constant, so comparing weights is equivalent.
6. **Hard decision** is `Λ ≤ 0 → ê = 1`, equality included.
7. **min1 location** is by *value* (`|msg| == min1`), not by index, so repeated
   minima all receive min2.

---

## 6. What the harness checks — and what it does not

Checked, per case:

* **validity** — if your decoder claims success, `H·ê = s` must hold. A failure
  here is a false positive and is the only hard error the harness returns non-zero for.
* **converged flag** agreement with the reference.
* **solution weight** vs the reference: better / equal / worse.
* **bit-identical ê** (reported, not required).

**Not** checked: bit-exactness. It is not achievable against this reference and
the reason is structural, not a bug on either side:

* the public reference forces the data scale S and the memory scale M to be the
  same value, so at int4.2.8 (S = 2, M = 8) its γ₀ = 0.125 truncates to 0;
* the rounding order differs — your `memory_strength_mult` multiplies then
  shifts, the reference computes `(λ/S)·(S−γ)` and divides first. With λ = 4,
  β = 7 you get 3 and it gets 0.

Under int4 these are different algorithms. Which one is right is a research
decision. The oracle here therefore runs in **f64** — it encodes what the
decoder is supposed to do, not what a particular fixed-point pipeline does.

---

## 7. Case groups and known limits

| group | n | p | purpose |
|---|---|---|---|
| `A_w**` | 10 | 0.05 | fixed weights 0–12, regression / smoke |
| `B_col***` | 7 | 0.05 | single-column errors at both block boundaries — catches column-indexing bugs |
| `P01`…`P15` | 490 | 0.01–0.15 | the working range; leg-0 convergence through multi-leg |
| `C20`,`C25`,`C30` | 45 | 0.20–0.30 | deliberately over-noised, to exercise the failure path |

Limits you should keep in mind when quoting numbers from this suite:

* **Code-level, not circuit-level.** The paper's Fig. 7 is a 12+1-cycle circuit
  experiment on a DEM matrix (the reference ships one: 1008 × 8785 with 100
  sampled syndromes). This suite is code-capacity on 72 × 144. Running the paper's
  R = 600 here is a budget match, not an experiment match.
* **Group C is not physical.** p = 0.20–0.30 means weight-30-to-55 errors on a
  distance-12 code. Convergence there means "found *a* valid coset
  representative", nothing about logical success. Quote group C separately.
* **The interface takes an error vector, not a syndrome.** The cases ship both
  `err` and `synd`; the adapter passes `err` because that is what `decode_relay()`
  accepts today. Circuit-level work will need the syndrome entry point.
* **The oracle converges for every case at R = 600**, so this suite does not
  discriminate on non-convergence at the paper budget. Use `hw_R8_*` (13
  reference non-convergences) or move to circuit level for that.
